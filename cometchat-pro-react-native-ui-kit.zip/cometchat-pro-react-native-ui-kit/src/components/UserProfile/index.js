export { default as CometChatUserProfile } from './CometChatUserProfile';
