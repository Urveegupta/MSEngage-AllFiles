import { StyleSheet } from 'react-native';

import { calc, deviceHeight } from '../../../utils/consts';

export default StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.7)',
  },
  reactionDetailsContainer: {
    backgroundColor: 'white',
    paddingVertical: 20,
    borderRadius: 20,
  },
  headerContainerStyle: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  contactWrapperStyle: {
    height: '100%',
    backgroundColor: 'white',
  },
  contactHeaderStyle: {
    paddingBottom: 14,
    position: 'relative',
    paddingHorizontal: 25,
  },
  contactHeaderCloseStyle: {
    height: 24,
    width: '33%',
  },
  contactHeaderTitleStyle: {
    margin: 0,
    fontWeight: '700',
    textAlign: 'left',
    fontSize: 28,
  },
  contactSearchStyle: {
    padding: 4,
    marginTop: 10,
    flexDirection: 'row',
    position: 'relative',
    alignItems: 'center',
    width: '100%',
    borderWidth: 0,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.2,
    shadowRadius: 1.41,
  },
  contactSearchInputStyle: {
    flex: 1,
    paddingVertical: 4,
    marginHorizontal: 8,
    fontSize: 15,
  },
  contactMsgStyle: {
    overflow: 'hidden',
    width: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  contactMsgTxtStyle: {
    margin: 0,
    height: 30,
    fontSize: 24,
    fontWeight: '600',
  },
  contactListStyle: {
    height: 400,
    margin: 0,
    padding: 0,
  },
  contactAlphabetStyle: {
    padding: 0,
    paddingVertical: 8,
    backgroundColor: 'white',
    width: '100%',
    paddingHorizontal: 15,
  },
  contactAlphabetTextStyle: {
    fontSize: 18,
    opacity: 0.4,
  },
  itemSeperatorStyle: {
    borderBottomWidth: 1,
    width: '85%',
    alignSelf: 'flex-end',
    paddingHorizontal: 15,
  },
  headerContainer: {
    alignItems: 'center',
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 15,
    paddingVertical: 15,
  },
  addBtnStyle: {
    borderRadius: 10,
    padding: 10,
    paddingHorizontal: 15,
  },
  addBtnTxtStyle: {
    fontSize: 14,
    fontWeight: '500',
  },
  listContainer: {
    height: deviceHeight * 0.8,
  },
});
