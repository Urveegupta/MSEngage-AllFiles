export { default as incomingMessageAlert } from './incomingmessage.wav';
export { default as incomingOtherMessageAlert } from './incomingothermessage.wav';
export { default as outgoingMessageAlert } from './outgoingmessage.wav';
export { default as incomingCallAlert } from './incomingcall.wav';
export { default as outgoingCallAlert } from './outgoingcall.wav';
